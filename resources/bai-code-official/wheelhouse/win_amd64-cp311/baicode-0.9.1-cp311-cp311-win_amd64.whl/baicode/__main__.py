from baicode.cli import main

main()
