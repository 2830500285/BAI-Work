"""Centralized theme system — colors, symbols, and console singleton.

All CLI styling flows through this module. Other modules import `console`
and `symbols` from here instead of creating their own Rich instances.
"""

import os
import sys

from rich.console import Console
from rich.theme import Theme

# ---------------------------------------------------------------------------
# Semantic color palette (ANSI 8/16 only for maximum terminal compatibility)
# ---------------------------------------------------------------------------
STYLES = Theme({
    "theme.success": "green",
    "theme.error": "red bold",
    "theme.warning": "yellow",
    "theme.info": "cyan",
    "theme.dim": "dim",
    "theme.emphasis": "bold",
    "theme.accent": "bright_black",
    "theme.border.primary": "bright_black",
    "theme.border.secondary": "dim",
})

# ---------------------------------------------------------------------------
# Console singleton — all output goes through this
# ---------------------------------------------------------------------------
console = Console(theme=STYLES)

# ---------------------------------------------------------------------------
# Terminal capability detection
# ---------------------------------------------------------------------------

def _supports_unicode() -> bool:
    """Detect whether the current terminal can render Unicode symbols."""
    # 1. TERM=dumb → no Unicode
    if os.environ.get("TERM") == "dumb":
        return False

    # 2. Non-UTF encoding → no Unicode
    encoding = getattr(sys.stdout, "encoding", "") or ""
    if encoding.lower().replace("-", "") not in ("utf8", "utf16"):
        return False

    # 3. Windows without Windows Terminal → no Unicode
    if sys.platform == "win32" and not os.environ.get("WT_SESSION"):
        return False

    return True

# ---------------------------------------------------------------------------
# Unicode / ASCII symbol sets
# ---------------------------------------------------------------------------
UNICODE_SYMBOLS = {
    "prompt": "❯",
    "success": "◍",
    "error": "◍",
    "warning": "◍",
    "pending": "◔",
    "active": "◍",
    "separator": "─",
    "arrow": "→",
}

ASCII_SYMBOLS = {
    "prompt": ">",
    "success": "[OK]",
    "error": "[ERR]",
    "warning": "[!]",
    "pending": ".",
    "active": "*",
    "separator": "-",
    "arrow": "->",
}

symbols = UNICODE_SYMBOLS if _supports_unicode() else ASCII_SYMBOLS

# ---------------------------------------------------------------------------
# Brand ASCII art banner
# ---------------------------------------------------------------------------
BANNER = """\
██████   █████  ██
██   ██ ██   ██ ██
██████  ███████ ██
██   ██ ██   ██ ██
██████  ██   ██ ██"""
